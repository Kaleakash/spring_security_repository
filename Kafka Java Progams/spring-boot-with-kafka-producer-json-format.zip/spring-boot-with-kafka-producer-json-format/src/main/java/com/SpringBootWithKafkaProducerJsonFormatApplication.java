package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithKafkaProducerJsonFormatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithKafkaProducerJsonFormatApplication.class, args);
	}

}
